
function calculate() {
  const temperature = parseFloat(document.getElementById('temperature').value);
  const blastVolume = parseFloat(document.getElementById('blastVolume').value);
  const blastPressure = parseFloat(document.getElementById('blastPressure').value);
  const furnacePressure = parseFloat(document.getElementById('furnacePressure').value);
  const oxygenEnrichment = parseFloat(document.getElementById('oxygenEnrichment').value);
  const humidity = parseFloat(document.getElementById('humidity').value);
  const oreCokeRatio = parseFloat(document.getElementById('oreCokeRatio').value);
  const slagCoefficient = parseFloat(document.getElementById('slagCoefficient').value);

  const hotMetalOutput = blastVolume * 0.008 * oreCokeRatio;
  const slagOutput = hotMetalOutput * slagCoefficient;
  const tappingTime = hotMetalOutput / 4.5;

  document.getElementById('results').innerHTML = `
    <p>예상 출선량: ${hotMetalOutput.toFixed(1)} 톤</p>
    <p>예상 슬래그량: ${slagOutput.toFixed(1)} 톤</p>
    <p>예상 출선시간: ${tappingTime.toFixed(1)} 분</p>
  `;
}
